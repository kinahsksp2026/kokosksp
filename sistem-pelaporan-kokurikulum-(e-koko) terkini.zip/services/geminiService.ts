
import { GoogleGenAI } from "@google/genai";
import { KokoReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeWeeklyReports(reports: KokoReport[]) {
  if (reports.length === 0) return "Tiada data untuk dianalisis.";

  const prompt = `Berikut adalah data aktiviti kokurikulum mingguan sekolah:
  ${JSON.stringify(reports)}
  
  Sila berikan rumusan ringkas dalam Bahasa Melayu yang merangkumi:
  1. Tahap kehadiran keseluruhan.
  2. Aktiviti yang paling menonjol.
  3. Cadangan penambahbaikan untuk minggu hadapan.
  
  Formatkan dalam perenggan yang profesional.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Gagal menjana analisis.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Ralat berlaku semasa menjana analisis pintar.";
  }
}
