
export enum Category {
  UNIFORM = 'Unit Beruniform',
  CLUB = 'Kelab & Persatuan',
  SPORT = 'Sukan & Permainan'
}

export enum UserRole {
  ADMIN = 'PENTADBIR',
  REPORTER = 'PELAPOR'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  unit?: string; // Optional unit for reporters
}

export interface KokoReport {
  id: string;
  date: string;
  week: number;
  category: Category;
  unitName: string;
  teacherInCharge: string;
  attendancePresent: number;
  attendanceAbsent: number;
  activityDescription: string;
  achievements: string;
  createdAt: number;
  reporterId: string;
  reporterName: string;
}

export interface AppSettings {
  googleSitesUrl: string;
  lookerStudioUrl: string;
  googleDriveFolderId: string;
  schoolName: string;
}
