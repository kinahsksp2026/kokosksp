
import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Settings, 
  PlusCircle, 
  Trash2, 
  Download, 
  ExternalLink,
  Search,
  School,
  PieChart as PieChartIcon,
  Cloud,
  FileBarChart,
  User as UserIcon,
  LogOut,
  ShieldCheck,
  UserCircle,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Filter,
  X
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend 
} from 'recharts';
import { KokoReport, Category, AppSettings, User, UserRole } from './types';
import { analyzeWeeklyReports } from './services/geminiService';

const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Ali (Admin)', role: UserRole.ADMIN },
  { id: 'u2', name: 'Siti (Reporter)', role: UserRole.REPORTER, unit: 'Pengakap' },
  { id: 'u3', name: 'Raju (Reporter)', role: UserRole.REPORTER, unit: 'Kelab Robotik' },
];

const INITIAL_SETTINGS: AppSettings = {
  googleSitesUrl: 'https://sites.google.com/view/ekoko-sk-digital',
  lookerStudioUrl: 'https://lookerstudio.google.com/reporting/demo',
  googleDriveFolderId: '',
  schoolName: 'SK DIGITAL MALAYSIA'
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [reports, setReports] = useState<KokoReport[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'calendar' | 'settings'>('dashboard');
  const [settings, setSettings] = useState<AppSettings>(INITIAL_SETTINGS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Filtering State
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // Calendar State
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Load state
  useEffect(() => {
    const savedReports = localStorage.getItem('koko_reports');
    const savedSettings = localStorage.getItem('koko_settings');
    const savedUser = localStorage.getItem('koko_user');
    if (savedReports) setReports(JSON.parse(savedReports));
    if (savedSettings) setSettings(JSON.parse(savedSettings));
    if (savedUser) setCurrentUser(JSON.parse(savedUser));
  }, []);

  // Save state
  useEffect(() => {
    localStorage.setItem('koko_reports', JSON.stringify(reports));
    localStorage.setItem('koko_settings', JSON.stringify(settings));
    if (currentUser) localStorage.setItem('koko_user', JSON.stringify(currentUser));
    else localStorage.removeItem('koko_user');
  }, [reports, settings, currentUser]);

  const addReport = (reportData: Omit<KokoReport, 'id' | 'createdAt' | 'reporterId' | 'reporterName'>) => {
    if (!currentUser) return;
    const newReport: KokoReport = {
      ...reportData,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      reporterId: currentUser.id,
      reporterName: currentUser.name
    };
    setReports([newReport, ...reports]);
    setIsModalOpen(false);
  };

  const deleteReport = (id: string) => {
    const report = reports.find(r => r.id === id);
    if (!report || !currentUser) return;

    const canDelete = currentUser.role === UserRole.ADMIN || report.reporterId === currentUser.id;

    if (!canDelete) {
      alert('Anda tiada kebenaran untuk memadam laporan ini.');
      return;
    }

    if (window.confirm('Adakah anda pasti ingin memadam laporan ini?')) {
      setReports(reports.filter(r => r.id !== id));
    }
  };

  const handleAiAnalysis = async () => {
    setIsAnalyzing(true);
    const analysis = await analyzeWeeklyReports(reports);
    setAiAnalysis(analysis);
    setIsAnalyzing(false);
  };

  const filteredReports = useMemo(() => {
    return reports.filter(r => {
      const matchesSearch = 
        r.unitName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.activityDescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.reporterName.toLowerCase().includes(searchTerm.toLowerCase());
      
      const reportDate = r.date; // Format YYYY-MM-DD
      const matchesStart = !startDate || reportDate >= startDate;
      const matchesEnd = !endDate || reportDate <= endDate;

      return matchesSearch && matchesStart && matchesEnd;
    });
  }, [reports, searchTerm, startDate, endDate]);

  const resetFilters = () => {
    setSearchTerm('');
    setStartDate('');
    setEndDate('');
  };

  const stats = useMemo(() => {
    const byCategory = {
      [Category.UNIFORM]: reports.filter(r => r.category === Category.UNIFORM).length,
      [Category.CLUB]: reports.filter(r => r.category === Category.CLUB).length,
      [Category.SPORT]: reports.filter(r => r.category === Category.SPORT).length,
    };

    const attendanceData = reports.map(r => ({
      name: r.unitName,
      present: r.attendancePresent,
      absent: r.attendanceAbsent
    })).slice(0, 5);

    const pieData = [
      { name: 'Uniform', value: byCategory[Category.UNIFORM], color: '#3B82F6' },
      { name: 'Kelab', value: byCategory[Category.CLUB], color: '#10B981' },
      { name: 'Sukan', value: byCategory[Category.SPORT], color: '#F59E0B' },
    ];

    return { byCategory, attendanceData, pieData };
  }, [reports]);

  // Calendar Helpers
  const calendarDays = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    const days = [];
    // Previous month blanks
    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }
    // Current month days
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    return days;
  }, [currentMonth]);

  const changeMonth = (offset: number) => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + offset, 1));
  };

  const getReportsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return reports.filter(r => r.date === dateStr);
  };

  // Auth Guard
  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-indigo-900 p-4">
        <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-md animate-in fade-in zoom-in-95 duration-300">
          <div className="flex flex-col items-center mb-8">
            <div className="bg-indigo-100 p-4 rounded-2xl text-indigo-600 mb-4">
              <School size={48} />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Selamat Datang ke e-KOKO</h1>
            <p className="text-gray-500 text-center mt-2">Sila pilih akaun untuk mula menggunakan sistem</p>
          </div>
          <div className="space-y-3">
            {MOCK_USERS.map(user => (
              <button
                key={user.id}
                onClick={() => setCurrentUser(user)}
                className="w-full flex items-center justify-between p-4 rounded-2xl border-2 border-gray-100 hover:border-indigo-500 hover:bg-indigo-50 transition-all text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${user.role === UserRole.ADMIN ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'}`}>
                    {user.role === UserRole.ADMIN ? <ShieldCheck size={20} /> : <UserCircle size={20} />}
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">{user.name}</p>
                    <p className="text-xs text-gray-500">{user.role}</p>
                  </div>
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <LogOut size={18} className="rotate-180 text-indigo-500" />
                </div>
              </button>
            ))}
          </div>
          <p className="mt-8 text-center text-xs text-gray-400">© 2025 Sistem Pengurusan Kokurikulum Digital</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-indigo-900 text-white flex-shrink-0 flex flex-col no-print shadow-2xl z-20">
        <div className="p-6 flex items-center gap-3 border-b border-indigo-800">
          <div className="bg-white p-2 rounded-lg">
            <School className="text-indigo-900" size={24} />
          </div>
          <h1 className="font-bold text-xl tracking-tight">e-KOKO</h1>
        </div>
        
        {/* User Profile Info */}
        <div className="p-6 bg-indigo-950/50">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-indigo-700 flex items-center justify-center border-2 border-indigo-400">
                <UserIcon size={20} />
              </div>
              <div className="overflow-hidden">
                <p className="font-bold text-sm truncate">{currentUser.name}</p>
                <div className="flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${currentUser.role === UserRole.ADMIN ? 'bg-amber-400' : 'bg-emerald-400'}`}></span>
                  <p className="text-[10px] text-indigo-300 uppercase tracking-widest font-bold">{currentUser.role}</p>
                </div>
              </div>
           </div>
           <button 
             onClick={() => setCurrentUser(null)}
             className="mt-4 w-full flex items-center justify-center gap-2 py-2 text-xs text-indigo-300 hover:text-white hover:bg-white/10 rounded-lg transition-all"
           >
             <LogOut size={14} />
             Log Keluar
           </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 mt-2">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'dashboard' ? 'bg-indigo-700 text-white shadow-lg' : 'text-indigo-200 hover:bg-indigo-800'}`}
          >
            <LayoutDashboard size={20} />
            <span className="font-medium">Papan Pemuka</span>
          </button>
          <button 
            onClick={() => setActiveTab('reports')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'reports' ? 'bg-indigo-700 text-white shadow-lg' : 'text-indigo-200 hover:bg-indigo-800'}`}
          >
            <FileText size={20} />
            <span className="font-medium">Senarai Laporan</span>
          </button>
          <button 
            onClick={() => setActiveTab('calendar')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'calendar' ? 'bg-indigo-700 text-white shadow-lg' : 'text-indigo-200 hover:bg-indigo-800'}`}
          >
            <CalendarIcon size={20} />
            <span className="font-medium">Kalendar Aktiviti</span>
          </button>
          {currentUser.role === UserRole.ADMIN && (
            <button 
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'settings' ? 'bg-indigo-700 text-white shadow-lg' : 'text-indigo-200 hover:bg-indigo-800'}`}
            >
              <Settings size={20} />
              <span className="font-medium">Konfigurasi</span>
            </button>
          )}
        </nav>

        <div className="p-4 border-t border-indigo-800 space-y-2">
          <a href={settings.googleSitesUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-indigo-400 hover:text-white px-2 py-1">
            <span>Google Sites</span>
            <ExternalLink size={10} />
          </a>
          <a href={settings.lookerStudioUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-indigo-400 hover:text-white px-2 py-1">
            <span>Looker Studio</span>
            <ExternalLink size={10} />
          </a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 no-print">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 capitalize">
                {activeTab === 'dashboard' ? 'Papan Pemuka' : 
                 activeTab === 'reports' ? 'Senarai Laporan' : 
                 activeTab === 'calendar' ? 'Kalendar Aktiviti' : 
                 'Tetapan'}
              </h2>
              <p className="text-gray-500 mt-1">{settings.schoolName}</p>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-2 bg-white border border-gray-200 text-gray-700 px-4 py-2.5 rounded-xl hover:bg-gray-50 shadow-sm transition-all"
              >
                <Download size={18} />
                <span>Eksport PDF</span>
              </button>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl hover:bg-indigo-700 shadow-md transition-all font-medium"
              >
                <PlusCircle size={18} />
                <span>Lapor Baru</span>
              </button>
            </div>
          </header>

          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                    <School size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-medium">Unit Beruniform</p>
                    <p className="text-2xl font-bold">{stats.byCategory[Category.UNIFORM]}</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                    <FileBarChart size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-medium">Kelab & Persatuan</p>
                    <p className="text-2xl font-bold">{stats.byCategory[Category.CLUB]}</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
                    <PieChartIcon size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-medium">Sukan & Permainan</p>
                    <p className="text-2xl font-bold">{stats.byCategory[Category.SPORT]}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-96">
                  <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">Distribusi Aktiviti</h3>
                  <ResponsiveContainer width="100%" height="80%">
                    <PieChart>
                      <Pie
                        data={stats.pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {stats.pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend verticalAlign="bottom" height={36}/>
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-96">
                  <h3 className="font-bold text-gray-800 mb-4">Analisis Kehadiran</h3>
                  <ResponsiveContainer width="100%" height="80%">
                    <BarChart data={stats.attendanceData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" fontSize={10} />
                      <YAxis fontSize={12} />
                      <Tooltip />
                      <Bar dataKey="present" name="Hadir" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="absent" name="Tidak Hadir" fill="#EF4444" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {currentUser.role === UserRole.ADMIN && (
                <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-8 rounded-3xl border border-indigo-100 no-print">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-indigo-600 p-2 rounded-lg text-white">
                        <Cloud size={20} />
                      </div>
                      <h3 className="text-xl font-bold text-indigo-900">Rumusan Gemini AI (Khusus Pentadbir)</h3>
                    </div>
                    <button 
                      onClick={handleAiAnalysis}
                      disabled={isAnalyzing || reports.length === 0}
                      className="bg-indigo-600 text-white px-6 py-2 rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-all font-medium flex items-center gap-2"
                    >
                      {isAnalyzing ? 'Sedang Menganalisis...' : 'Jana Analisis Pintar'}
                    </button>
                  </div>
                  {aiAnalysis && (
                    <div className="bg-white p-6 rounded-2xl shadow-sm text-gray-700 leading-relaxed animate-in fade-in slide-in-from-bottom-2 duration-500">
                      <p className="whitespace-pre-line">{aiAnalysis}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'reports' && (
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row md:items-center gap-4 no-print">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input 
                    type="text" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Cari unit, aktiviti, atau nama pelapor..." 
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-gray-50 rounded-2xl px-4 py-2 ring-1 ring-gray-100">
                    <CalendarIcon size={16} className="text-gray-400 mr-2" />
                    <input 
                      type="date" 
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="bg-transparent border-none text-xs font-bold focus:ring-0 outline-none text-gray-600"
                    />
                    <span className="mx-2 text-gray-300 font-bold">ke</span>
                    <input 
                      type="date" 
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="bg-transparent border-none text-xs font-bold focus:ring-0 outline-none text-gray-600"
                    />
                  </div>
                  
                  {(searchTerm || startDate || endDate) && (
                    <button 
                      onClick={resetFilters}
                      className="p-3 bg-red-50 text-red-500 rounded-2xl hover:bg-red-100 transition-all group"
                      title="Set semula penapis"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50/50 text-gray-500 text-[10px] uppercase tracking-widest font-bold">
                    <tr>
                      <th className="px-6 py-4">Tarikh</th>
                      <th className="px-6 py-4">Unit / Kategori</th>
                      <th className="px-6 py-4">Kehadiran</th>
                      <th className="px-6 py-4">Aktiviti</th>
                      <th className="px-6 py-4">Dilapor Oleh</th>
                      <th className="px-6 py-4 no-print text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredReports.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-16 text-center">
                           <div className="flex flex-col items-center gap-2 opacity-30">
                              <FileText size={48} />
                              <p className="font-medium">Tiada rekod ditemui</p>
                           </div>
                        </td>
                      </tr>
                    ) : (
                      filteredReports.map((report) => {
                        const isOwner = report.reporterId === currentUser.id;
                        const isAdmin = currentUser.role === UserRole.ADMIN;
                        const canDelete = isAdmin || isOwner;

                        return (
                          <tr key={report.id} className="hover:bg-gray-50 transition-colors group">
                            <td className="px-6 py-4">
                              <div className="font-bold text-gray-900">{new Date(report.date).toLocaleDateString('ms-MY')}</div>
                              <div className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter">Minggu {report.week}</div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="font-bold text-indigo-900">{report.unitName}</div>
                              <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                                report.category === Category.UNIFORM ? 'bg-blue-100 text-blue-700' :
                                report.category === Category.CLUB ? 'bg-emerald-100 text-emerald-700' :
                                'bg-amber-100 text-amber-700'
                              }`}>
                                {report.category}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <div className="inline-flex items-center bg-gray-100 px-2 py-1 rounded-lg">
                                <span className="text-emerald-600 font-black text-sm">{report.attendancePresent}</span>
                                <span className="text-gray-300 mx-1">/</span>
                                <span className="text-gray-500 font-bold text-sm">{report.attendancePresent + report.attendanceAbsent}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">{report.activityDescription}</td>
                            <td className="px-6 py-4">
                               <div className="flex items-center gap-2">
                                  <div className={`p-1 rounded ${isOwner ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400'}`}>
                                    <UserIcon size={12} />
                                  </div>
                                  <span className={`text-sm font-medium ${isOwner ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
                                    {isOwner ? 'Saya' : report.reporterName}
                                  </span>
                               </div>
                            </td>
                            <td className="px-6 py-4 text-right no-print">
                              {canDelete && (
                                <button 
                                  onClick={() => deleteReport(report.id)}
                                  className="p-2 text-red-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                >
                                  <Trash2 size={18} />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'calendar' && (
            <div className="space-y-6">
              <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <h3 className="text-2xl font-black text-indigo-950">
                      {currentMonth.toLocaleDateString('ms-MY', { month: 'long', year: 'numeric' })}
                    </h3>
                    <div className="flex items-center gap-1 bg-gray-50 p-1 rounded-xl">
                      <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-white hover:shadow-sm rounded-lg transition-all text-gray-600">
                        <ChevronLeft size={20} />
                      </button>
                      <button onClick={() => setCurrentMonth(new Date())} className="px-3 py-1 text-xs font-bold uppercase tracking-widest text-indigo-600 hover:bg-white hover:shadow-sm rounded-lg transition-all">
                        Harini
                      </button>
                      <button onClick={() => changeMonth(1)} className="p-2 hover:bg-white hover:shadow-sm rounded-lg transition-all text-gray-600">
                        <ChevronRight size={20} />
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest text-gray-400">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 bg-blue-500 rounded-full"></span>
                      <span>Uniform</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
                      <span>Kelab</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 bg-amber-500 rounded-full"></span>
                      <span>Sukan</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-7 gap-px bg-gray-100 border border-gray-100 rounded-2xl overflow-hidden">
                  {['Ahad', 'Isnin', 'Selasa', 'Rabu', 'Khamis', 'Jumaat', 'Sabtu'].map(day => (
                    <div key={day} className="bg-gray-50 p-4 text-center text-xs font-black uppercase tracking-widest text-gray-400">
                      {day}
                    </div>
                  ))}
                  {calendarDays.map((day, idx) => {
                    if (!day) return <div key={`empty-${idx}`} className="bg-white min-h-[120px]"></div>;
                    
                    const dayReports = getReportsForDate(day);
                    const isToday = day.toDateString() === new Date().toDateString();

                    return (
                      <div key={day.getTime()} className={`bg-white min-h-[120px] p-2 border-t border-gray-50 hover:bg-indigo-50/30 transition-colors group relative ${isToday ? 'ring-2 ring-indigo-500 ring-inset' : ''}`}>
                        <div className={`text-sm font-black mb-2 ${isToday ? 'text-indigo-600' : 'text-gray-400'}`}>
                          {day.getDate()}
                        </div>
                        <div className="space-y-1">
                          {dayReports.map(r => (
                            <div 
                              key={r.id}
                              onClick={() => { setActiveTab('reports'); setSearchTerm(r.unitName); }}
                              className={`text-[10px] p-1.5 rounded-lg font-bold truncate cursor-pointer transition-all hover:scale-105 active:scale-95 ${
                                r.category === Category.UNIFORM ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                                r.category === Category.CLUB ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' :
                                'bg-amber-100 text-amber-700 border border-amber-200'
                              }`}
                            >
                              {r.unitName}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && currentUser.role === UserRole.ADMIN && (
            <div className="max-w-2xl bg-white p-10 rounded-3xl shadow-sm border border-gray-100">
              <h3 className="text-2xl font-black mb-8 flex items-center gap-3 text-indigo-900">
                <Settings className="text-indigo-600" />
                Sistem & Integrasi
              </h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Nama Sekolah</label>
                  <input 
                    type="text" 
                    value={settings.schoolName}
                    onChange={(e) => setSettings({...settings, schoolName: e.target.value})}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-indigo-500 focus:bg-white outline-none transition-all font-bold text-gray-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Integrasi Google Sites</label>
                  <input 
                    type="url" 
                    value={settings.googleSitesUrl}
                    onChange={(e) => setSettings({...settings, googleSitesUrl: e.target.value})}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium text-gray-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Integrasi Looker Studio</label>
                  <input 
                    type="url" 
                    value={settings.lookerStudioUrl}
                    onChange={(e) => setSettings({...settings, lookerStudioUrl: e.target.value})}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-indigo-500 focus:bg-white outline-none transition-all font-medium text-gray-600"
                  />
                </div>
                <div className="pt-6">
                  <button className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 shadow-xl shadow-indigo-200 transition-all">
                    Kemaskini Tetapan
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Report Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/40 backdrop-blur-md p-4 no-print">
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-indigo-50/50">
              <div>
                <h3 className="text-2xl font-black text-indigo-950">Lapor Aktiviti</h3>
                <p className="text-indigo-400 text-xs font-bold uppercase tracking-widest mt-1">Mingguan Kokurikulum</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white text-gray-400 hover:text-red-500 shadow-sm transition-all">
                <Trash2 size={20} className="rotate-45" />
              </button>
            </div>
            
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              addReport({
                date: formData.get('date') as string,
                week: Number(formData.get('week')),
                category: formData.get('category') as Category,
                unitName: formData.get('unitName') as string,
                teacherInCharge: formData.get('teacher') as string,
                attendancePresent: Number(formData.get('present')),
                attendanceAbsent: Number(formData.get('absent')),
                activityDescription: formData.get('description') as string,
                achievements: formData.get('achievements') as string,
              });
            }} className="p-10 grid grid-cols-2 gap-6 max-h-[75vh] overflow-y-auto">
              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Tarikh</label>
                <input required name="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-4 py-3 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all" />
              </div>
              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Minggu</label>
                <input required name="week" type="number" defaultValue={1} className="w-full px-4 py-3 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all font-bold" />
              </div>
              
              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Kategori</label>
                <select name="category" className="w-full px-4 py-3 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all font-bold text-gray-700">
                  <option value={Category.UNIFORM}>{Category.UNIFORM}</option>
                  <option value={Category.CLUB}>{Category.CLUB}</option>
                  <option value={Category.SPORT}>{Category.SPORT}</option>
                </select>
              </div>
              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Nama Unit/Sukan</label>
                <input required name="unitName" defaultValue={currentUser.unit || ''} placeholder="Pengakap / Bola Sepak" className="w-full px-4 py-3 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all font-bold" />
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Guru Penasihat Bertugas</label>
                <input required name="teacher" defaultValue={currentUser.name} className="w-full px-4 py-3 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all font-medium" />
              </div>

              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2 text-emerald-600">Hadir</label>
                <input required name="present" type="number" defaultValue={0} className="w-full px-4 py-3 bg-emerald-50 text-emerald-700 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-emerald-500 transition-all font-black text-center" />
              </div>
              <div className="col-span-1">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2 text-red-600">Tidak Hadir</label>
                <input required name="absent" type="number" defaultValue={0} className="w-full px-4 py-3 bg-red-50 text-red-700 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-red-500 transition-all font-black text-center" />
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Huraian Aktiviti Mingguan</label>
                <textarea required name="description" rows={4} placeholder="Ceritakan apa yang dilakukan pada perjumpaan kali ini..." className="w-full px-5 py-4 bg-gray-50 rounded-[1.5rem] border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all text-sm leading-relaxed"></textarea>
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Pencapaian / Catatan Khas</label>
                <input name="achievements" placeholder="Tiada" className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none outline-none ring-2 ring-transparent focus:ring-indigo-500 transition-all text-sm" />
              </div>

              <div className="col-span-2 flex gap-4 pt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-8 py-4 border-2 border-gray-100 text-gray-500 rounded-2xl hover:bg-gray-50 transition-all font-black uppercase tracking-widest">
                  Batal
                </button>
                <button type="submit" className="flex-1 px-8 py-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all font-black uppercase tracking-widest shadow-xl shadow-indigo-100">
                  Hantar Laporan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print View Styling */}
      <style>{`
        @media print {
          body { background: white; padding: 0 !important; }
          main { padding: 0 !important; }
          .max-w-6xl { max-width: 100%; margin: 0; }
          table { font-size: 9pt; border-collapse: collapse; width: 100%; }
          th, td { border: 1px solid #eee; }
          .no-print { display: none !important; }
          header { margin-bottom: 2rem; border-bottom: 2px solid #312e81; padding-bottom: 1rem; }
          aside { display: none !important; }
        }
      `}</style>
    </div>
  );
};

export default App;
